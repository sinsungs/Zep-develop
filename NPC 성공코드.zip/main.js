// // 플레이어가 입장할 때 동작하는 함수
// App.onJoinPlayer.Add(function(player){
// 	App.sayToAll(`id: ${player.id} name: ${player.name}`);
//   })


App.onObjectTouched.Add(function (sender, x, y, tileID, obj) {
    if (obj !== null) {
        if (obj.type == ObjectEffectType.INTERACTION_WITH_ZEPSCRIPTS) {
            App.sayToAll(`Number = ${obj.text}, Value = ${obj.param1}`, 0xFFFFFF);
			App.sayToAll(`Name = ${sender.name}, id = ${sender.id}`, 0xFFFFFF);


			// const currentTime = new Date().toLocaleTimeString();
			// const currentTime = new Date().toString();
			const currentTime = new Date().toTimeString();
			
			App.httpPostJson(
				"http://ec2-43-201-154-148.ap-northeast-2.compute.amazonaws.com/index.php",
				// "https://postman-echo.com/post" ,
				// "http://localhost:8080/api/zepeto",
				{
					// "test-header": "zep",
				},
				{
					name: sender.name,
					challenge: currentTime
				},
				(res) => {
					
					App.sayToAll(`HTTP Result: ${JSON.stringify(res)}`);
				}
			);
        }
    } else {
        App.sayToAll(`obj is null`, 0xFFFFFF);
    }
});