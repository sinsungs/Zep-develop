// Q
App.addOnKeyDown(81, function (player) {
	// player.showEmbed("https://youtu.be/ztuTrpXJyks", "middle", 900, 600, true);
	player.showEmbed("https://godsaengbucket.s3.ap-northeast-2.amazonaws.com/2023-06-25T15%3A52%3A07.683047_2101134_%EC%8B%AC%EC%83%81%ED%9D%AC.png", "middle", 900, 600, true);
});